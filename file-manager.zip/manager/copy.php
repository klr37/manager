<?php
session_start();
include 'head.php';
if(isset($_GET['file'])){
   $file = $_GET['file'];
   $goBack = realpath(dirname($file));
   if(!is_file($file)){
      echo '<center><b><font color="red">File không tồn tại</font></b></center>
<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
      include 'foot.php'; exit;
   }
   if(isset($_POST['save'])){
      $name = $_POST['name'];
      $newfile = str_replace($file, $name, $file);
      if(@copy($file,$newfile)){
         echo '<center><font color="green"><b>Sao chép thành công</b></font></center>';
      }else{
         echo '<center><font color="red"><b>Lỗi không sao chép được</b></font></center>';
      }
   }else{
      echo 'Nhập đường dẫn mới<br />
<form action="" method="post">
<input type="text" name="name" value="' . $file .'" /><br />
<input type="submit" name="save" value="Save" />
</form>';
   }
echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
}
//
include 'foot.php';
