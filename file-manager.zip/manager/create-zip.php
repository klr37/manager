<?php
session_start();
include 'head.php';
include 'inc/pclzip.php';
if(isset($_GET['file'])){
   $file = $_GET['file'];
   $goBack = realpath(dirname($file));
   if(!is_file($file)){
      echo '<center><b><font color="red">File không tồn tại</font></b></center>
<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
      include 'foot.php'; exit;
   }
   if(isset($_POST['ok'])){
      $arch = new PclZip($_POST["name"]);
      $value = $arch->add($file, PCLZIP_OPT_REMOVE_PATH, realpath(dirname($file)));
      if($value){
         echo '<center><b><font color="green">Đóng gói thành công</font></b><br /><a href="download.php?file=' . realpath(dirname($file)) . '/' . $_POST["name"] . '">Tải xuống</a></center>';
      }else{
         echo '<center><b><font color="red">Đóng gói lỗi</font></b></center>';
         echo $arch->errorInfo(true);
      }
   }else{
      echo '<form action="" method="post">
Nhập tên file zip<br />
<input type="text" name="name" value="daiviet.zip" /><br />
<input type="submit" name="ok" value="Tạo" />
</form>';
   }
echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php'; exit;
}
//zip dir
if(isset($_GET['dir'])){
   $dir = $_GET['dir'];
   $goBack = $dir;
   if(!is_dir($dir)){
      echo '<center><b><font color="red">Thư mục không tồn tại</font></b></center>
<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
      include 'foot.php'; exit;
   }
   if(isset($_POST['czip'])){
      $arch = new PclZip($dir . '/' . $_POST["name"]);
      $value = $arch->add($dir, PCLZIP_OPT_REMOVE_PATH, $dir);
      if($value){
         echo '<center><b><font color="green">Đóng gói thành công</font></b><br /><a href="download.php?file=' . $dir . '/' . $_POST["name"] . '">Tải xuống</a></center>';
      }else{
         echo '<center><b><font color="red">Đóng gói lỗi</font></b></center>';
         echo $arch->errorInfo(true);
      }
   }else{
      echo '<form action="" method="post">
Nhập tên file zip<br />
<input type="text" name="name" value="daiviet.zip" /><br />
<input type="submit" name="czip" value="Tạo" />
</form>';
   }
echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php';
}