<?php
session_start();
include 'head.php';
//if create file
if(isset($_GET['file'])){
   $file = $_GET['file'];
   $goBack = $file;
   if(isset($_POST['cre'])){
      if(realpath(dirname(__FILE__))==$file){$fname=$_POST['fname'];}else{$fname = $file.'/'.$_POST["fname"];}
      if(file_exists($fname)){
         echo '<center><font color="red"><b>File đã tồn tại</b></font></center>';
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
         include 'foot.php'; exit;
      }else{
         $data='#YManager#';
         if($fname=='.htaccess' || $fname=='php.ini'){
            $data="\r\n";
         }
         if(@file_put_contents($fname, $data)){
           echo '<center><font color="green"><b>Tạo file mới thành công</b></font></center>';
         }else{
            echo '<center><font color="red"><b>Không thể tạo file mới</b></font></center>';
         }
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
         include 'foot.php'; exit;
      }
   }else{
   echo 'Nhập tên file cần tạo<br /><form action="" method="post">
<input type="text" name="fname" /><br />
<input type="submit" name="cre" value="Tạo" />
</form>';
   echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php'; exit;
   }
}
//if create dir
if(isset($_GET['dir'])){
   $dir = $_GET['dir'];
   $goBack = $dir;
   if(isset($_POST['cre'])){
      $dname = $dir.'/'.$_POST["dname"];
      if(is_dir($dname)){
         echo '<center><font color="red"><b>Thư mục đã tồn tại</b></font></center>';
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
         include 'foot.php'; exit;
      }else{
         if(@mkdir($dname)){
            echo '<center><b><font color="green">Tạo thư mục mới thành công</font></b></center>';
         }else{
            echo '<center><b><font color="red">Không thể tạo thư mục</font></b></center>';
         }
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
         include 'foot.php'; exit;
      }
   }else{
      echo 'Nhập tên thư mục<br /><form action="" method="post">
<input type="text" name="dname" /><br />
<input type="submit" name="cre" value="Tạo" />
</form>';
      echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php';
   }
}
