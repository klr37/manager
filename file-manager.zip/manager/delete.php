<?php
session_start();
include 'head.php';
//if is delete file
if(isset($_GET['file'])){
   $file = $_GET['file'];
   $goBack = realpath(dirname($file));
   if(!isset($_GET['confirm'])){
      echo 'Bạn chắc chắn muốn xóa file<br /><a href="delete.php?file=' . $file . '&confirm=yes">Có</a> | <a href="delete.php?file=' . $file . '&confirm=no">Không</a>';
   }else{
      if($_GET['confirm']=="yes"){
         unlink($file);
         echo '<center><b><font color="green">Đã xóa file</font></b></center>';
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
      }else{
         header('location:'.$_SERVER["HTTP_REFERER"]);
      } //end isset $_GET['confirm']
   }
}
//if is delete dir
if(isset($_GET['dir'])){
   $dir = $_GET['dir'];
   $goBack = $dir;
   if(!isset($_GET['confirm'])){
      echo 'Bạn chắc chắn muốn xóa thư mục<br /><a href="delete.php?dir=' . $dir . '&confirm=yes">Có</a> | <a href="delete.php?dir=' . $dir . '&confirm=no">Không</a>';
   }else{
      if($_GET['confirm']=="yes"){
         if(deldir($dir)){
            echo '<center><b><font color="green">Đã xóa thư mục</font></b></center>';
         }else{
            echo '<center><b><font color="red">Lỗi!!! Không xóa được thư mục</font></b></center>';
         }
         echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
      }else{
         header('location:'.$_SERVER["HTTP_REFERER"]);
      } //end isset $_GET['confirm']
   }
}
include 'foot.php';
