<?php
session_start();
include 'head.php';
$dir = $_GET['dir'];

include 'inc/class.dirsize.php';
$dirsize = new DirSize;
$arr = $dirsize->size($dir);

//$arr = dirinfo($dir);
if(is_dir($dir)){
$dirname = end(explode('/', $dir));
echo 'Thư mục : <b><font color="green">' . $dirname . '</font></b><br />
Kích thước : <font color="red">' . size_convert($arr["size"]) . '</font><br />
__________<br />';
echo '» <a href="index.php?dir=' . realpath(dirname($dir)) . '">Trở lại</a><br />
» <a href="index.php?dir=' . $dir . '">Xem</a><br />
» <a href="rename.php?dir=' . $dir . '">Đổi tên</a><br />
» <a href="delete.php?dir=' . $dir . '">Xóa</a><br />
» <a href="create-zip.php?dir=' . $dir .'">Tạo zip</a>';
}else{
echo '<center><b><font color="red">Thư mục không tồn tại</font></b></center>';
}
include 'foot.php';
