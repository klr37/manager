<?php
session_start();
if(!$_SESSION['admin']) header('location:login.php');
$link = $_GET['file'];
$fp = fopen($link, 'rb');
header('content-disposition: attachment; filename="'.$link.'"');
header("content-type: application/octet-stream");
header("content-length: " . filesize($link));
fpassthru($fp);
fclose($fp);
