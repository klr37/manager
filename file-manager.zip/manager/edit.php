<?php
session_start();
include 'head.php';
if(isset($_GET['file'])){
   $file = $_GET['file'];
   echo 'Sửa tệp : <b><font color="darkblue">' . end(explode("/",$file)) . '</font></b><br />';
   if(isset($_POST['save'])){
      if(@file_put_contents($file, htmlspecialchars_decode(stripslashes($_POST['cont'])))){
         echo '<center><font color="green"><b>Lưu thành công</b></font></center>';
      }else{
         echo '<center><font color="red"><b>Lưu thất bại</b></font></center>';
      }
   }
   $content = file_get_contents($file);
   echo '<form action="" method="post">
<textarea name="cont" width="95%">' . htmlspecialchars($content) . '</textarea><br />
<input type="submit" name="save" value="save" />
</form>';
$goBack = realpath(dirname($_GET['file']));
}

if(isset($_GET['empty'])){
   $emp = $_GET['empty'];
   if(file_put_contents($emp,' ')){
      echo '<center><b><font color="green">Làm rỗng thành công</font></b></center>';
   }else{
      echo '<center><b><font color="red">Không thể làm rỗng</font></b></center>';
   }
$goBack = realpath(dirname($_GET['empty']));
}

echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php';
