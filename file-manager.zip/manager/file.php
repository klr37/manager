<?php
session_start();
include 'head.php';
$file = $_GET['file'];
if(is_file($file)){
$filetype = file_type($file);
$filename = end(explode('/', $file));
echo 'Tệp: <b><font color="green">' . $filename . '</font></b><br />
Sửa lần cuối : <font color="blue">' . date("d M Y H:i:s", filemtime($file)) . '</font><br />
Kích thước : <font color="orange">' . size_convert(filesize($file)) . '</font><br />
Định dạng : <font color="brown">' . $filetype . '</font><br />
__________<br />';
//get direct link of file
$realpath = realpath(__FILE__);
$text = str_replace($_SERVER["SCRIPT_NAME"], '', $realpath);
$direct_link = str_replace($text, '', $file);
$homeurl = 'http://'.$_SERVER["HTTP_HOST"];
//
$imgtype = 'jpg png gif bmp ico jpeg';
if(preg_match('#'.$filetype.'#is', $imgtype)){
   echo '<img src="download.php?file=' . $file . '" width="30%"/><br />';
}elseif($filetype=='zip'){
   echo '» <a href="viewzip.php?arch=' . $file . '">Xem lưu trữ</a><br />
» <a href="unzip.php?file=' . $file . '">Giải nén</a><br />';
}
echo '» <a href="' . $homeurl . $direct_link . '">Xem</a><br />
» <a href="download.php?file=' . $file . '">Tải xuống</a><br />
» <a href="rename.php?file=' . $file . '">Đổi tên</a><br />
» <a href="delete.php?file=' . $file . '">Xóa</a><br />
» <a href="copy.php?file=' . $file . '">Sao chép</a><br />
» <a href="move.php?file=' . $file . '">Di chuyển</a><br />
» <a href="edit.php?file=' . $file . '">Sửa</a><br />
» <a href="view.php?file=' . $file . '">Xem mã</a><br />
» <a href="edit.php?empty=' . $file . '">Làm rỗng</a><br />
» <a href="create-zip.php?file=' . $file . '">Tạo zip</a><br />
» <a href="index.php?dir=' . realpath(dirname($file)) . '">Trở lại</a><br /';
}else{
echo '<center><b><font color="red">File không tồn tại</font></b></center>';
}
include 'foot.php';
