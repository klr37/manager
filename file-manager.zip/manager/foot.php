<div class="footer">
<b><center>
   YManager v.1.0.1<br />
   © 2013 by NTD
</center></b>
</div>
</body>
</html>
<?php ob_end_flush(); ?>
