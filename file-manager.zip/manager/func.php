<?php
function dirinfo($directory){
        $handle = scandir($directory);
        array_shift($handle); array_shift($handle);
        $size = 0; $folders = 0; $files = 0;
        foreach($handle as $file){
                   if(is_dir($file)){
             $array = dirinfo($file);
             $size += $array['size'];
             $files += $array['files'];
             $folders += $array['folders'];
                   }else{
             $size += filesize($directory.'/'.$file);
             $files++;
                   }
         }
         $folders++;
       return array('size' => $size, 'files' => $files, 'folders' => $folders);
}
//page navigation
function pagenavi($link, $num_bv, $page_bv) {
if($page_bv!=1 && $num_bv!=0) {
echo str_replace('%d_pg', ($page_bv-1), "<a href='$link'><b>Trước</b></a>");
}
if($page_bv!=$num_bv && $num_bv!="0") {
echo str_replace('%d_pg', ($page_bv+1), '<a href="'.$link.'"><b>Tiếp</b></a>');
}
}
//size convert
function size_convert($a_bytes){
if($a_bytes < 1024){
return $a_bytes .' B';
}elseif($a_bytes < 1048576){
return round($a_bytes / 1024, 2) .' KB';
}elseif($a_bytes < 1073741824){
return round($a_bytes / 1048576, 2) . ' MB';
}elseif($a_bytes < 1099511627776){
return round($a_bytes / 1073741824, 2) . ' GB';
}elseif($a_bytes < 1125899906842624){
return round($a_bytes / 1099511627776, 2) .' TB';
}elseif($a_bytes < 1152921504606846976){
return round($a_bytes / 1125899906842624, 2) .' PB';
}elseif($a_bytes < 1180591620717411303424){
return round($a_bytes / 1152921504606846976, 2) .' EB';
}elseif($a_bytes < 1208925819614629174706176){
return round($a_bytes / 1180591620717411303424, 2) .' ZB';
}else{
return round($a_bytes / 1208925819614629174706176, 2) .' YB';
}
}
//file type
function file_type($name){
$c = strrpos($name, '.');
$type = substr($name, $c+1, 255);
return strtolower($type);
}
//delete directory
function deldir($dir){
if(is_dir($dir)){
$objects = scandir($dir);
foreach($objects as $object){
if($object != '.' && $object != '..'){
if(filetype($dir.'/'.$object)=='dir'){
deldir($dir.'/'.$object);
}else{
unlink($dir.'/'.$object);
}
}
}
}
reset($objects);
if(rmdir($dir)){return TRUE;}else{return FALSE;}
}
