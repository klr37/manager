<?php
error_reporting(0);
ob_start();
$getConfig = file_get_contents('config.php');
$conf = explode('|',$getConfig);
$wb_config['fpp'] = $conf[0];
$wb_config['user'] = $conf[1];
$wb_config['pass'] = $conf[2];
$wb_config['lpp'] = $conf[3];
include 'func.php';
if(!$_COOKIE['ymanager'] && !preg_match('#login.php#is', $_SERVER['REQUEST_URI'])){header('location:login.php');}
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="vi">
<head>
<title>YManager v.1.0.1</title>
<meta name="title" content="YManager v.1.0.1" />
<meta name="description" content="Dễ dàng quản lý file trên host với YManager. Mã nguồn viết bởi NTD" />
<meta http-equiv="Content-Type" content=
"text/html; charset=utf-8" />
<link rel="shortcut icon" href="http://wapmienphi.com/favicon.ico" />
<link rel="stylesheet" type="text/css" href="style.css" media="all,handheld" />
</head>
<body>
<div class="header"><a href="index.php"><img src="img/home.gif" /></a>';
if($_COOKIE['ymanager']){echo ' | <a href="user.php">User</a> | <a href="logout.php">Đăng xuất</a>';}
echo '</div>';
