<?php
session_start();
include 'head.php';
$path = $_GET['path'];
if(isset($_POST['im'])){
   $cont = file_get_contents($_POST['link']);
   $name = end(explode('/',$_POST['link']));
   $fn = $path.'/'.$name;
   if(@file_put_contents($fn,$cont)){
       echo '<center><font color="green"><b>Nhập khẩu thành công</b></font></center>';
   }else{
       echo '<center><font color="red"><b>Không thể nhập khẩu</b></font></center>';
   }
}
echo 'Nhập link file(tối đa ' . ini_get("upload_max_filesize") . ')<br />
<form action="" method="post">
<input type="text" name="link" value="http://" /><br />
<input type="submit" name="im" value="nhập khẩu" />
</form>';
echo '<div class="goback"><a href="index.php?dir=' . $path . '">Trở lại</a></div>';
include 'foot.php';