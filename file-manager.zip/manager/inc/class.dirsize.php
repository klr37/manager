<?php 
class DirSize {
    function calculate_whole_directory($directory)
    {
        $handle = scandir($directory);
        array_shift($handle); array_shift($handle);
        $size = 0; $folders = 0; $files = 0;
        foreach($handle as $file){
                   if(is_dir($file)){
             $array = $this->calculate_whole_directory($file);
             $size += $array['size'];
             $files += $array['files'];
             $folders += $array['folders'];
                   }else{
             $size += filesize($directory.'/'.$file);
             $files++;
                   }
         }
         $folders++;
       return array('size' => $size, 'files' => $files, 'folders' => $folders);
    }

     function size($directory)
     {
     $array = $this->calculate_whole_directory($directory);
     $bytes = $array['size'];
     $files = $array['files'];
     $folders = $array['folders'] - 1; // exclude the main folder
     return array('size' => $bytes, 'files' => $files, 'folders' => $folders);
     }
}
?>