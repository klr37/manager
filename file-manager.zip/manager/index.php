<?php
session_start();
$realpath = realpath(dirname(dirname(__FILE__)));
//kiem tra so trang
if(!isset($_GET['page']) || $_GET['page']==NULL){$page=1;}else{$page=$_GET['page'];}
//
if(!isset($_GET['dir']) && !isset($_GET['updir'])){$getdir = $realpath;}else{$getdir = $_GET["dir"];}
if(is_file($getdir)){header('location:file.php?file=' . $getdir);}
if(isset($_GET['updir']) && !isset($_GET['dir'])){$getdir = $_GET['updir'];}

include 'head.php';
echo '<a href="create.php?dir=' . $getdir . '">Tạo folder</a> | <a href="create.php?file=' . $getdir . '">Tạo file</a> | <a href="import.php?path=' . $getdir . '">Import file</a> | <a href="upload.php?dir=' . $getdir . '">Upload</a><br />
<form action="" method="get" name="changedir">
<input type="text" name="dir" value="' . $getdir . '" />
<input type="submit" value="Go" />
</form><br />';
if(!is_dir($getdir)){
   echo '<center><b><font color="red">Thư mục không tồn tại</font></b></center>';
}else{
//lay danh sach file, dem so file
   $list = array();
   $list = scandir($getdir);
   array_shift($list); array_shift($list);
   $total = count($list);
   $row_p = $wb_config['fpp'];
   $start_p = ($row_p*$page)-$row_p;
   $num_p = ceil($total/$row_p);
   $limit = ($total<$row_p)?($total):($start_p+$row_p);
   $updir = realpath(dirname($getdir));
//start print
   echo '<table width="100%">
<tr><img src="img/back.png" /><a href="index.php?updir=' . $updir . '">../</a></tr>';
   echo '<form action="multi-action.php" method="post" name="multi-action">';
   for($i=$start_p;$i<$limit;$i++){
      if(array_key_exists($i,$list)){
         if(is_dir($getdir.'/'.$list[$i]) && $i!=$limit){
echo '<tr><td><input type="checkbox" name="files[]" value="' . $getdir . '/' . $list[$i] . '" /><img src="img/dir.gif" /><a href="index.php?dir=' . $getdir . '/' . $list[$i] . '">' . $list[$i] . '</a> [<a href="dir.php?dir=' . $getdir . '/' . $list[$i] . '">Quản lý</a>]</td></tr>';
         }elseif(is_file($getdir.'/'.$list[$i])){
echo '<tr><td><input type="checkbox" name="files[]" value="' . $getdir . '/' . $list[$i] . '" /><a href="file.php?file=' . $getdir . '/' . $list[$i] . '">' . $list[$i] . '</a> ' . size_convert(filesize($getdir."/".$list[$i])) . '</td></tr>';
         }
      }
   }
echo '</table>
<script language="javascript" src="inc/select-all-files.js"></script>
<input type="checkbox" onclick="toggle(this)" /> Chọn tất cả<br />
<input type="submit" name="delete" value="Xóa" />
<input type="submit" name="move" value="Di chuyển" />
<input type="submit" name="rename" value="Đổi tên" />
<input type="submit" name="addzip" value="Tạo ZIP" />
</form><br />';
if(!preg_match('#\?(dir|updir)#is', $_SERVER["REQUEST_URI"])){$plink='index.php?dir='.$getdir.'&page=%d_pg';}else{$plink='index.php?dir='.$getdir.'&page=%d_pg';}

echo pagenavi($plink,$num_p,$page) . '
<form action="index.php" method="get" name="gotopage">
<input type="hidden" name="dir" value="' . $getdir . '" />
<input size="4" type="text" name="page" value="' . $page .'" />
<input type="submit" value="Go" />
</form><br />
Tổng số trang : '.$num_p;
}
include 'foot.php';
