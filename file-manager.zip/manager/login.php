<?php
session_start();
if($_COOKIE['ymanager']){header('location:index.php');}
include 'head.php';
if(isset($_POST['log'])){
   if($_POST['user']==NULL || $_POST['pass']==NULL){
      echo '<center><font color="red">Chưa nhập đủ thông tin</font></center>';
   }
   if(!$_POST['user']==NULL || !$_POST['pass']==NULL || (!$_POST['user']==$wb_config['user'] || !$_POST['pass']==$wb_config['pass'])){
      echo '<center><font color="red">Sai username hoặc password</font></center>';
   }
   if($_POST['user']==$wb_config['user'] && $_POST['pass']==$wb_config['pass']){
      setcookie('ymanager', $wb_config['user'], time()+3600*24*30);
      header('location:index.php');
   }
}
echo '<form action="" method="post">
Tên đăng nhập<br />
<input type="text" name="user" value="' . $_POST["user"] . '" /><br />
Mật khẩu<br />
<input type="password" name="pass" value="' . $_POST["pass"] . '" /><br />
<input type="submit" name="log" value="Login" />
</form>';
include 'foot.php';
