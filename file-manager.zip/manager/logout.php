<?php
session_start();
session_destroy();
include 'head.php';
setcookie('ymanager', '', time()-3600*24*365*10);
if($_COOKIE['ymanager']){
   unset($_COOKIE['ymanager']);
   if(!$_COOKIE['ymanager']){
       header('location:login.php');
   }else{
       echo 'Lỗi, hãy refresh lại trang';
   }
}else{
   header('location:login.php');
}
include 'foot.php';
