<?php
session_start();
include 'head.php';
//ZIP FILE
if(isset($_POST['addzip'])){
   include 'inc/pclzip.php';
   if(isset($_POST['ok'])){
      $zpath = realpath(dirname($_POST['files'][0]));
      $mz = implode(',',$_POST['files']);
      $arch = new PclZip($zpath . '/' . $_POST["zname"]);
      $value = $arch->add($mz, PCLZIP_OPT_REMOVE_PATH, $zpath);
      if($value){
         echo '<center><b><font color="green">Đóng gói thành công</font></b></center>';
      }else{
         echo '<center><b><font color="red">Đóng gói lỗi</font></b></center>';
         echo $arch->errorInfo(true);
      }
      include 'foot.php'; exit;
   }else{
      echo '<form action="" method="post">
Nhập tên file zip<br />
<input type="text" name="zname" value="daiviet.zip" />
<input type="hidden" name="addzip" value="addzip" />';
      foreach($_POST['files'] as $file){
         echo '<input type="hidden" name="files[]" value="' . $file . '" />';
      }
      echo '<input type="submit" name="ok" value="Tạo" /></form>';
      include 'foot.php'; exit;
   }
}
//DELETE FILE
if(isset($_POST['delete'])){
    if(isset($_POST['ok'])){
       foreach($_POST['file'] as $file){
          if(is_file($file)){
             if(unlink($file)){
                echo '<b>» <font color="green">Đã xóa file</font></b> ' . end(explode("/",$file)) . '<br />';
             }else{
                echo '<b>» <font color="red">Không xóa được file</font></b> ' . end(explode("/",$file)) . '<br />';
             }
          }elseif(is_dir($file)){
             if(deldir($file)){
                echo '<b>» <font color="green">Đã xóa thư mục</font></b> ' . end(explode("/",$file)) . '<br />';
             }else{
                echo '<b>» <font color="red">Không xóa được thư mục</font></b> ' . end(explode("/",$file)) . '<br />';
             }
          }
       }//end foreach
       include 'foot.php'; exit;
   }
   if(isset($_POST['no'])){
        header('location:'.$_POST["refer"]);
   }
   if(!isset($_POST['ok']) && !isset($_POST['no'])){
      echo '<form action="" method="post" name="delete-file">
<input type="hidden" name="delete" value="delete" />
Bạn chắc chắn muốn xóa các file này<br />';
      foreach($_POST['files'] as $df){
         echo '<input type="hidden" name="file[]" value="' . $df .'" />';
      }
      echo '<input type="submit" name="ok" value="Có" />
<input type="hidden" name="refer" value="' . $_SERVER["HTTP_REFERER"] . '" />
<input type="submit" name="no" value="Không" />
</form>';
      include 'foot.php'; exit;
   }
}
//MOVE. FILE
if(isset($_POST['move'])){
   if(isset($_POST['ok'])){
           $newDir = $_POST['newdir'];
        foreach($_POST['file'] as $file){
           $oldDir = realpath(dirname($file));
           $fileName = end(explode('/', $file));
           if(is_file($file)){
              if(@copy($file, $newDir.'/'.$fileName)){
                 @unlink($file);
                 echo '<b>» <font color="green">Đã di chuyển file</font></b> ' . $fileName .'<br />';
              }else{
                 echo '<b>» <font color="red">Không di chuyển được file</font></b> ' . $fileName .'<br />';
              }
           }else{
              echo '<b>» <font color="red">Không di chuyển được thư mục</font></b> ' . $fileName .'<br />';
           }
        }
        include 'foot.php'; exit;
   }else{
      echo '<form action="" method="post" name="move-file">
Nhập đường dẫn mới<br />';
   foreach($_POST['files'] as $gf){
      echo '<input type="hidden" name="file[]" value="' . $gf . '" />';
   }
      echo '<input type="hidden" name="move" value="move" />
<input type="text" name="newdir" value="' . realpath(dirname($_POST["files"][0])) . '" /><br />
<input type="submit" name="ok" value="OK" />
</form>';
      include 'foot.php'; exit;
   }
}
//RENAME
if(isset($_POST['rename'])){
   if(isset($_POST['rn'])){
      $i=0;
      foreach($_POST['files'] as $file){
            if(rename($_POST['oname'][$i],$file)){
               echo '» <font color="green">Đổi tên thành công</font> ' . end(explode("/", $_POST["oname"][$i])) . '<br />';
            }else{
               echo '» <font color="red">Đổi tên thất bại</font> ' . end(explode("/", $file)) . '<br />';
            }
         $i++;
      } //end foreach
      include 'foot.php'; exit;
   }else{
      echo '<form action="" method="post">
Nhập lại tên mới<br />
<input type="hidden" name="rename" value="rename" />';
      foreach($_POST['files'] as $rf){
          echo '<input type="text" name="files[]" value="' . $rf .'" /><br /><br />
<input type="hidden" name="oname[]" value="' . $rf .'" />';
      }
      echo '<input type="submit" name="rn" value="Có" />
<input type="submit" name="norn" value="Không" />
<input type="hidden" name="refer" value="' . $_SERVER["HTTP_REFERER"] .'" />
</form>';
      include 'foot.php';
   }
   if(isset($_POST['norn'])){
      header('location:'. $_POST["refer"]);
   }
}
