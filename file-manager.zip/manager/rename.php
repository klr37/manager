<?php
session_start();
include 'head.php';
//rename file
if(isset($_GET['file'])){
$file = $_GET['file'];
$goBack = realpath(dirname($file));
   if(isset($_POST['save'])){
      $oldname = end(explode('/',$file));
      $newname = $_POST['name'];
      $name = str_replace($oldname, $newname, $file);
      if(rename($file,$name)){
         echo '<center><font color="green"><b>Đổi tên thành công</b></font></center>';
      }else{
         echo '<center><font color="red"><b>Không đổi được tên</b></font></center>';
      }
   }else{
   echo 'Nhập tên mới<br />
<form action="" method="post">
<input type="text" name="name" /><br />
<input type="submit" name="save" value="save" />
</form>';
   }
echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
}
//rename dir
if(isset($_GET['dir'])){
$dir = $_GET['dir'];
   if(isset($_POST['save'])){
      $oldname = end(explode('/',$dir));
      $newname = $_POST['name'];
      $name = str_replace($oldname, $newname, $dir);
      if(@rename($dir,$name)){
         echo '<center><font color="green"><b>Đổi tên thành công</b></font></center>';
      }else{
         echo '<center><font color="red"><b>Không đổi được tên</b></font></center>';
      }
   }else{
   echo 'Nhập tên mới<br />
<form action="" method="post">
<input type="text" name="name" /><br />
<input type="submit" name="save" value="save" />
</form>';
   }
echo '<div class="goback"><a href="index.php?dir=' . $dir . '">Trở lại</a></div>';
}
include 'foot.php';
