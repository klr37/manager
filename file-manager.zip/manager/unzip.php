<?php
session_start();
include 'head.php';
include 'inc/pclzip.php';
$file = $_GET['file'];
$upath = realpath(dirname($file));
if(isset($_POST['unz'])){
   $arch = new PclZip($file);
   $value = $arch->extract(PCLZIP_OPT_PATH, $_POST['link']);
   if($value!=0){
      echo '<center><b><font color="green">Giải nén thành công</font></b></center>';
   }else{
      echo '<center><b><font color="red">Giải nén lỗi</font></b></center>';
   }
}else{
   echo '<form action="" method="post">
Nhập đường dẫn giải nén<br />
<input type="text" name="link" value="' . $upath . '" /><br />
<input type="submit" name="unz" value="Unzip" />
</form>';
}
echo '<div class="goback"><a href="index.php?dir=' . $upath . '">Trở lại</a></div>';
include 'foot.php';