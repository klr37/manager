<?php
session_start();
include 'head.php';
$dir = $_GET['dir'];
if(isset($_POST['up'])){
   $tmp_name = $_FILES['file_uploaded']['tmp_name'];
   $link = $dir.'/'.$_FILES["file_uploaded"]["name"];
   if(@copy($tmp_name,$link)){
      echo '<center><b><font color="green">Upload thành công</font></b></center>';
   }else{
      echo '<center><b><font color="red">Upload thất bại</font></b></center>';
   }
}
echo 'Upload tối đa ' . ini_get("upload_max_filesize") . '<br />
<form action="" method="post" enctype="multipart/form-data">
<input type="file" name="file_uploaded"><br />
<input type="submit" name="up" value="Upload" />
</form>';
echo '<div class="goback"><a href="index.php?dir=' . $dir . '">Trở lại</a></div>';
include 'foot.php';