<?php
session_start();
if(isset($_POST['save'])){
$cu = file_get_contents('config.php');
$cf = explode('|',$cu);
$cf[0] = $_POST['fpp'];
$cf[1] = $_POST['user'];
$cf[2] = $_POST['pass'];
   if(@file_put_contents('config.php', implode('|',$cf))){
      $_SESSION['alert'] = '<center><b><font color="green">Lưu thành công</font></b></center>';
   }else{
      $_SESSION['alert'] = '<center><b><font color="red">Lưu thất bại</font></b></center>';
   }
}
include 'head.php';
echo $_SESSION['alert']; unset($_SESSION['alert']);
echo '<form action="" method="post" name="user">
Tên đăng nhập(a->z và 0-8)<br />
<input type="text" name="user" value="' . $wb_config["user"] . '" /><br />
Mật khẩu(a->z và 0->9)<br />
<input type="text" name="pass" value="' . $wb_config["pass"] . '" /><br />
Số file trên một trang<br />
<input type="text" name="fpp" value="' . $wb_config["fpp"] . '" /><br />
<input type="submit" name="save" value="Lưu" />
</form>';
include 'foot.php';
