<?php
session_start();
include 'head.php';
$file = $_GET['file'];
$goBack = realpath(dirname($file));
$content = file_get_contents($file);
echo 'Tệp : <a href="file.php?file=' . $file . '">' . end(explode("/",$file)) . '</a><br />';
echo highlight_string($content);
echo '<div class="goback"><a href="index.php?dir=' . $goBack . '">Trở lại</a></div>';
include 'foot.php';
