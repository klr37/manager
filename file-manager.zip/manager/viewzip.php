<?php
session_start();
include 'head.php';
include 'inc/pclzip.php';
$udata[2] = 20;
$script_filename = end(explode('/',realpath(__FILE__)));
$arch=$_GET['arch'];
if (!$_GET['action']){
$zip=new PclZip($_GET['arch']);
   if (($list = $zip->listContent()) != 0){
      sort($list);
      $total = count($list);
      echo '<div class="mainmenu">';
      echo 'Tên <b>'.strtolower(substr($arch, 1 + strrpos($arch, "/"))).'</b><br><br>';
      echo 'Tổng số tập tin: '.$total.'<br>';
      $start = (int)$_GET['start'];
      if($start < 0 || $start > $total){$start = 0;}
      if ($total < $start + $udata[2]){ $end = $total; }else {$end = $start + $udata[2]; }

      for ($i = $start; $i < $end; $i++){
         $ext=strtolower(strrchr($list[$i]['filename'], "."));
         if($list[$i]['folder']=="1"){
            $list[$i]['filename']=substr($list[$i]['filename'],0,-1);
            echo '<b>Thư mục '.$list[$i]["filename"].'</b><br>';
         }else{
            echo ' <a href="' . $script_filename .'?action=preview&arch='.$arch.'&open='.$list[$i]["filename"].'&start='.$start.'&">'.$list[$i]["filename"].'</a>';
echo ' ('.size_convert($list[$i]["size"]).')<br>';
         }
      }
      echo '<br>';
      if($total>0){
         $ba=ceil($total/$udata[2]);
         $ba2=$ba*$udata[2]-$udata[2];
         echo '<br><br>Các trang:';
         $asd=$start-($udata[2]*3);
         $asd2=$start+($udata[2]*4);
         if($asd<$total && $asd>0){echo ' <a href="' . $script_filename .'?start=0&arch='.$arch.'&">1</a> ... ';}

         for($i=$asd; $i<$asd2;){
            if($i<$total && $i>=0){
               $ii=floor(1+$i/$udata[2]);
               if ($start==$i) {echo ' <b>('.$ii.')</b>';}else{echo ' <a href="' . $script_filename .'?start='.$i.'&arch='.$arch.'&">'.$ii.'</a> ';}
            }
            $i=$i+$udata[2];
         }

      if($asd2<$total){echo ' ... <a href="' . $script_filename .'?start='.$ba2.'&arch='.$arch.'&">'.$ba.'</a>';}
      }
   }else{
      echo '<br> Không thể mở tập tin! <br>';
      echo 'Lỗi: '.$zip->errorInfo(true);
   }
   echo '</div>';
   }

   if($_GET['action']=="preview"){
		
   $zip=new PclZip($arch);
   $content = $zip->extract(PCLZIP_OPT_BY_NAME, $_GET['open'],PCLZIP_OPT_EXTRACT_AS_STRING);
   $content = $content[0]['content'];

   $ext = strtolower(substr($_GET['open'], strrpos($_GET['open'], '.') + 1));

   echo 'Tiêu đề lưu trữ: <b>'.strtolower(substr($arch, 1 + strrpos($arch, "/"))).'</b><br>';
   echo 'Mở tập tin: <b>'.$_GET['open'].'</b><br>';

      if ($ext!="gif" && $ext!="jpg" && $ext!="png"){
         echo highlight_string($content);
         echo '<div class="imenu"><a href="' . $script_filename .'?arch='.$arch.'&start='.$_GET['start'].'&">Trở lại</a></div>';
      }else{
          if($_GET['create']=="image"){
             ob_end_clean();	
             ob_clean();
             header('Content-Disposition: attachment; filename="image.'.$ext.'";');
if($ext=="jpg"){$ext="jpeg";}
             header("Content-type: image/$ext");
             header("Content-Length: ".strlen($content));
             echo $content;
             exit;
          }
          echo'Image:<br> <a href="' . $script_filename .'?action=preview&arch='.$arch.'&open='.$_GET['open'].'&create=image">
<img src="' . $script_filename .'?action=preview&arch='.$arch.'&open='.$_GET['open'].'&create=image" alt=""></a><br>';
           echo '« <a href="' . $script_filename .'?arch='.$arch.'&start='.$_GET['start'].'&">Trở lại</a><br>';
    }
}

include 'foot.php';